from django.urls import path

from . import views
from .views import Home

urlpatterns = [
    path('home/', Home.as_view(), name='home'),
    path('lab1/', views.lab1_view, name='lab1'),
    path('lab2/', views.lab2_view, name='lab2'),
    path('lab3/', views.lab3_view, name='lab3'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('login-register/', views.login_register, name='login_register'),
]