import os

from django.conf import settings
from django.contrib import messages
from django.shortcuts import render
from django.views.generic import TemplateView
from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpResponse


def login_register(request):
    if request.method == 'POST':
        # Если это запрос на регистрацию
        if 'register' in request.POST:
            form = UserCreationForm(request.POST)
            if form.is_valid():
                form.save()
                messages.success(request, 'Реєстрація успішна! Тепер ви можете увійти.')
                return redirect('login_register')  # перенаправляем обратно на страницу
            else:
                messages.error(request, 'Помилка реєстрації.')

        # Если это запрос на вход
        elif 'login' in request.POST:
            email = request.POST['email']
            password = request.POST['password']
            user = authenticate(request, username=email, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')  # здесь можно перенаправить на главную страницу после входа
            else:
                messages.error(request, 'Невірний логін або пароль.')

    return render(request, 'login_register.html')

def lab1_view(request):
    # Указываем путь до папки Lab1
    lab1_path = os.path.join(settings.BASE_DIR, 'lab5', 'templates', 'labs', 'static', 'labs', 'Lab1')

    # Проверяем, существует ли директория
    if not os.path.exists(lab1_path):
        return render(request, 'labs/lab1.html', {'error': 'Директория не найдена!'})

    # Создаем структуру для файлов по папкам
    file_structure = {}

    for root, dirs, filenames in os.walk(lab1_path):
        relative_root = os.path.relpath(root, lab1_path)
        if relative_root == ".":  # Корневая директория
            relative_root = "Корневая папка"
        file_structure[relative_root] = {'dirs': dirs, 'files': filenames}

    return render(request, 'labs/lab1.html', {'file_structure': file_structure})

def lab2_view(request):
    # Указываем путь до папки Lab2 внутри static/labs
    lab2_path = os.path.join(settings.BASE_DIR, 'lab5', 'templates', 'labs', 'static', 'labs', 'Lab2')

    # Проверяем, существует ли эта директория
    if not os.path.exists(lab2_path):
        return render(request, 'labs/lab2.html', {'error': 'Директория не найдена!'})

    # Создаем структуру для файлов по папкам
    file_structure = {}

    # Проходим по всем папкам и файлам в структуре
    for root, dirs, filenames in os.walk(lab2_path):
        relative_root = os.path.relpath(root, lab2_path)
        if relative_root == ".":
            relative_root = ""  # Корневая директория Lab2

        # Добавляем директории и файлы в структуру
        file_structure[relative_root] = {'dirs': dirs, 'files': filenames}

    return render(request, 'labs/lab2.html', {'file_structure': file_structure})

def lab3_view(request):
    # Указываем путь до папки Lab2 внутри static/labs
    lab3_path = os.path.join(settings.BASE_DIR, 'lab5', 'templates', 'labs', 'static', 'labs', 'Lab3')

    # Проверяем, существует ли эта директория
    if not os.path.exists(lab3_path):
        return render(request, 'labs/lab3.html', {'error': 'Директория не найдена!'})

    # Создаем структуру для файлов по папкам
    file_structure = {}

    # Проходим по всем папкам и файлам в структуре
    for root, dirs, filenames in os.walk(lab3_path):
        relative_root = os.path.relpath(root, lab3_path)
        if relative_root == ".":
            relative_root = ""  # Корневая директория Lab2

        # Добавляем директории и файлы в структуру
        file_structure[relative_root] = {'dirs': dirs, 'files': filenames}

    return render(request, 'labs/lab3.html', {'file_structure': file_structure})


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})

# Вьюшка для входа
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

# Вьюшка для выхода
def logout_view(request):
    logout(request)
    return redirect('home')

class Home(TemplateView):

    template_name = 'mainpage.html'
